<?php
$say = "Hello " . $_GET['first_name'] . " " . $_GET['last_name'];
?>
<html>
<body>
<h1><?= $say ?></h1>
</body>
</html>
