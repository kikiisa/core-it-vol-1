<?php

header('Location: /phpinfo.php');
exit();
