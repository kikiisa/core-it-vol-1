<?php

$belajarCookie = $_COOKIE['X-BELAJAR-COOKIE'];

echo $belajarCookie;