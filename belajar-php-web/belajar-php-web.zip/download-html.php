<?php

header('Content-Disposition: attachment; filename="download.html"');
?>
<html>
<head>
    <title>Download HTML</title>
</head>
<body>
<h1>Download HTML</h1>
</body>
</html>
