<?php
echo "Belajar PHP Web <br/>" . PHP_EOL;
echo "Belajar PHP Web <br/>" . PHP_EOL;
echo "Belajar PHP Web <br/>" . PHP_EOL;