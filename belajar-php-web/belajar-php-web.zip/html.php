<?php
$title = "Hello PHP dan HTML";
$body = "Ini Adalah Body";
?>

<html>
<head>
    <title><?= $title ?></title>
</head>
<body>
<h1><?= $body ?></h1>
</body>
</html>
