<?php
setcookie("X-BELAJAR-COOKIE", "Mohamad Rizky Isa");

header('Location: /show-cookie.php');
