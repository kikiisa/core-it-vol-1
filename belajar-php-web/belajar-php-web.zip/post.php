<html>
<body>
<table>
    <tr>
        <td>First Name</td>
        <td><?= $_POST['first_name'] ?></td>
    </tr>
    <tr>
        <td>Last Name</td>
        <td><?= $_POST['last_name'] ?></td>
    </tr>
</table>
</body>
</html>