<html>
<body>
<h1>Register</h1>
<form action="post.php" method="post">
    <label> First Name :
        <input type="text" name="first_name">
    </label>
    <br/>
    <label> Last Name :
        <input type="text" name="last_name">
    </label>
    <br/>
    <input type="submit" value="Register">
</form>
</body>
</html>