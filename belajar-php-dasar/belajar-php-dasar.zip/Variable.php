<?php

$name = "Kiki";
$age = 20;

echo $name . ' umur ' . $age;


