<?php

var_dump("10" == 10);
var_dump("10" === 10);

var_dump(10 < 9);
var_dump(9 >= 9);