<?php

$a = 10;

$b = ++$a;

var_dump($a);
var_dump($b);
