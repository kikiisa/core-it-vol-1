<?php

var_dump(join(",", [10, 11, 12, 13, 14, 15]));
var_dump(explode(" ", "Mohamad Rizky Isa"));
var_dump(strtolower("Kiki Isa"));
var_dump(strtoupper("Kiki Isa"));
var_dump(trim("       Kiki Isa       "));
var_dump(substr("Kiki Isa", 0, 3));